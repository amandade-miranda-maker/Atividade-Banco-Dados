-- Active: 1780957228239@@127.0.0.1@3306
USE supermercado_xyz_db;

